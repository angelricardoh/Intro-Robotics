import math

def euclidean_distance(x, y):
    return math.sqrt(pow(x, 2) + pow(y, 2))